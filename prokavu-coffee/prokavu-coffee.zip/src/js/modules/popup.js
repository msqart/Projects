module.exports = (popup) => {

    const clsPopup = document.querySelectorAll('.popup_cls');
    const hiddenScroll = require('./functions/hiddenScroll');

    for (let i = 0; i < clsPopup.length; i++) {
        clsPopup[i].addEventListener('click', (evt) => {
            closePopup(popup);
        });
    }

    function closePopup (popup) {
        for (let i = 0; i < popup.length; i++) {
            popup[i].classList.remove('active');
            hiddenScroll(false, popup[i]);
        }
    }
};